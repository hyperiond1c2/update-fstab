#!/usr/bin/python
# [Version: 0.3]
# --------------------------------------------------------------
# Deprecated - only for testing if values were the correct
#              ones written in config and script by "2date.py"
#              P.S.: they should as the algo hasn't changed ;-)
# --------------------------------------------------------------

try:
    from sys import argv
    from binascii import crc32
except ImportError as ie:
    raise ie

def help():
    print "[-] Usage:\n\t%s file crcnod\n\te.g.: %s /tmp/fstab 0xffffffff\n" % (argv[0], argv[0])

if len(argv) < 3 or len(argv) >= 4:
    help()
    exit(0)
else:
    pass

ffobj = argv[1]
crcnod = argv[2]

def checksum(obj):
    try:
        fobj = open(obj, "r").read()
    except Exception as e:
        print "[-] Something went wrong.\n[*] Debugging info:\n"
        raise e
    return str(float(crc32(fobj) & int(crcnod, 16)))[:-2]
    
def main():
    print "[+] Starting engines ...\n"
    print "[i] Checksum for object \""+str(ffobj)+"\" is: "+str(checksum(ffobj))

if __name__ == "__main__":
    main()