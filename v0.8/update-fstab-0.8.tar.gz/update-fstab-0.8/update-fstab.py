#!/usr/bin/python
# [Version] 0.8 - 26.Jun - "Demeter"
# ----------------------------------
# Changelog
# ====================================================================================================================
# v0.8 [26.Jun]:
#    - cleaned up the code a bit and better parsing to switches have been implemented (maybe will port to OptionParser
#      in the near future);
#    - update-fstab.py "Demeter" - v0.8: ported to git;
#    - folders for logs and backups have been created separately, the config will now specify to the script to save
#      those in the local folders (this is to improve seeking the files also for readability and debugging).
#
# v0.7 [20.Jun]:
#    - updated the readings from the config (nothing biggie), more stable ones should be going on like you can mention
#      in the config file "fstab" and other filenames used by the script to parse;
#    - created "2date.py" script to automatically update the checksums of fstab file in config and of config in script.
# v0.6:
#    - finally 2.6 and 2.7 python have compatible functions for checksum and so on;
#    - updated the config file and improved the backup file (now you have to specify the path and filename);
#    - cleaned up the code a bit.
#
# v0.5:
#    - some new implementation for 2.6 and 2.7 python versions (detection and compatiblity issues solved);
#
# v0.2 - 0.4:
#    - nothing major.
#
# v0.1:
#    - initial release.
# ====================================================================================================================
# If you find any issues send them to me at roeglobal@insicuri.net and use my public PGP key (else no reply):
#     http://sprunge.us/UNOC
# ====================================================================================================================

# It should be self explanatory ...
try:
    from sys import argv
    from os import system as cmd
    from binascii import crc32
    from time import strftime
except ImportError as ie:
    print "[-] A module is missing.\n[*] Debugging info:\n"
    raise ie

def help():
    print "\n[i] Usage\n\t%s [switches] [options]\n\te.g.: %s /dev/mapper/DEVELOPMENT-depone /mnt/devel/departone ext3 defaults 1 2\n\te.g.: %s -c /dev/mapper-DEVELOPMENT-depone /mnt/devel/departone ext3\n\n[i] Use %s -hc to find out more about the `common template switch'\n" % (argv[0], argv[0], argv[0], argv[0])
    exit(0)
# ... until here

# switches
cmn = "-c" # common switch
helpc = "-hc" # help switch -c
# - - - - - -

if len(argv) <= 1:
    help()
    exit(0)

if argv[1] == cmn:
    if len(argv) < 5 or len(argv) >= 8:
        help()
        exit(0)

if argv[1] == helpc:    
    if len(argv) >= 2 and len(argv) <= 7:
        print "\n[i] The `-c' switch is there to specify the program to use the common template.\n\tMost of the times, sys administrators when updating the fstab, they usually do it with non-root devices.\n\tThis means that you don't have to specify each time the mtops,fs_freq and fs_passno fields to the program.\n\tInstead use the `-c' switch and specify only the mounting device (e.g.: /dev/mapper/DEVELOPMENT-users - for LVM2); mounting point (e.g.: /mnt/devel/users); and the filesystem it uses (e.g.: ext3)\n"
        exit(0)
elif len(argv) < 7 or len(argv) >= 8:
    help()
    exit(0)

# somewhat DEFINE  - C style ;-)
config="update-fstab.conf" # default config
confcache = 4234697104 # config cache checksum - use "2date.py" script to update this automatically or edit it by hand

# I too hate globals, but I couldn't find any other solutions (I hate classes too)
global fstab    # fstab file
global bak      # back-up location
global crcnod   # this is usually 0xffffffff - but you may change it in the config file. I use it to get rid of negative numbers
global cache    # cache sum for the fstab file
global logf      # log file to write verbosity to (mandatory)
changed=False
allfields = {}  # all fields if `-c' is not specified, this will be used
common = {} # common template that will be used if `-c' will be specified

# Read config stuff
def readfirst(cfg):
    global crcnod,logf
    data = open(cfg, "rb").readlines()
    for line in data:
        if "#" in line:
            pass
        else:
            if line == "":
                pass
            elif "crcnod:" in line:
                crcnod = line[7:].replace("\n", "")
                if crcnod == "" or crcnod == " ":
                    print "[-] You must specify a crcnod in the config file.\n"
                    exit(0)
            elif "log:" in line:
                logf = line[4:].replace("\n", "")
                if logf == "" or logf == " ":
                    print "[!] Log was not specified in your config file. Using default: \"log_ftab\"\n"
                    logf = "log_ftab"
                logf = logf+str("-"+strftime("%a_%d_%b-%Y-%H_%M_%S"))

readfirst(config)

# opening our logf to write data to
logdata = open(logf, "a")
logdata.write(" == BEGINNING OF LOG AT "+str(strftime("%a, %d %b %Y %H:%M:%S"))+" OF PROCESS ==\n"+"="*75+"\n")
# - - - - - - - - - - - - - - - - -
print "[i] Config loaded, initialising second step.\n"
logdata.write("[i] Config loaded, initialising second step.\n")
# - - - - - - - - - - - - - -

def checksum(obj):
    fobj = open(obj, "rb").read()
    return str(float(crc32(fobj) & int(crcnod, 16)))[:-2]
    del fobj

def readconf(cfg):
    global fstab,bak,crcnod,cache
    confsum = checksum(config)
    if confsum != str(confcache):
        print "[!] Please note that the config was changed since last use.\n[i] Config new checksum detected [%s]\n[!] The new settings that will be loaded may affect your fstab file if it wasn't you the one that made the changes.\n" % str(confsum)
        logdata.write("[!] Please note that the config was changed since last use.\n[i] Config new checksum detected [%s]\n\n[!] The new settings that will be loaded may affect your fstab file if it wasn't you the one that made the changes.\n" % str(confsum))
        cntinue = raw_input("[*] Do you still want to continue? [y(es)/n(o)]: ")
        logdata.write("[*] Do you still want to continue? [y(es)/n(o)]: \n")
        if cntinue.lower() == "y" or cntinue.lower() == "yes":
            print "[i] Continuing.\n"
            logdata.write("[i] Continuing.\n")
        elif cntinue.lower() == "n" or cntinue.lower() == "no":
            print "[i] Aborting and exiting with code 0.\n"
            logdata.write("\n[i] Aborting and exiting with code 0.\n")
            logdata.close()
            exit(0)
        else:
            print "[-] Input couldn't be understood. Aborting for safety reasons.\n"
            logdata.write("\n[-] Input couldn't be understood. Aborting for safety reasons.\n")
            logdata.close()
            exit(0)
    data = open(cfg, "rb").readlines()
    for line in data:
        if "#" in line:
            pass
        else:
            if line == "":
                pass
            elif "fstab:" in line:
                fstab = line[6:].replace("\n", "")
                if fstab == "" or fstab == " ":
                    print "[!] The fstab file was not specified in the config file. Using default: /etc/fstab\n"
                    logdata.write("\n[!] The fstab file was not specified in the config file. Using default: /etc/fstab\n")
                    fstab = "/etc/fstab"
            elif "bak:" in line:
                bak = line[4:].replace("\n", "")
                setbaktime = strftime("-%a_%d_%b-%Y-%H_%M_%S")
                if bak == "" or bak == " ":
                    print "[!] You did not specified any path for back-up. Using default: /tmp/ftab\n"
                    logdata.write("\n[!] You did not specified any path for back-up. Using default: /tmp/ftab\n")
                    bak = "/tmp/ftab.bak"+setbaktime
                else:
                    bak = line[4:].replace("\n", "")+".bak"+setbaktime
            elif "crcnod:" in line:
                crcnod = line[7:].replace("\n", "")
                if crcnod == "" or crcnod == " ":
                    print "[-] You must specify a crcnod in the config file.\n"
                    logdata.write("\n[-] You must specify a crcnod in the config file.\n")
                    logdata.close()
                    exit(0)
            elif "cache"+":" in line:
                cache = line[6:].replace("\n", "")
                if cache == "" or cache == " ":
                    print "[-] You must specify the cache of the fstab file in your config.\n"
                    logdata.write("\n[-] You must specify the cache of the fstab file in your config.\n")
                    logdata.close()
                    exit(0)

def backup():
    global fstab
    global bak
    filz = fstab+" "+bak
    print "[i] Back-up file is: \"%s\"" % str(bak)
    logdata.write("[i] Back-up file is \"%s\"\n" % str(bak))
    cmd("cp -p "+filz)

def checkfstab():
    global fstab,bak,cache
    fstabsum = checksum(fstab)
    if fstabsum != str(cache):
        print "[i] %s was changed since our last edit.\n[!] New cache (please be advised and update your conf): %s\n[i] Doing auto back-up before appending our modifications.\n" % (str(fstab), str(fstabsum))
        logdata.write("[i] %s was changed since our last edit.\n[!] New cache (please be advised and update your conf): %s\n\n[i] Doing auto back-up before appending our modifications.\n" % (str(fstab), str(fstabsum)))
        backup()
        print "[+] Back-up created successfully.\n"
        logdata.write("[+] Back-up created successfully.\n")
        changed = True
    else:
        changed = False
        mod = raw_input("[i] The fstab file wasn't changed since our last edit. Do you still want to make a back-up before appending our modifications? [y(es)/n(o)]: ")
        logdata.write("[i] The fstab file wasn't changed since our last edit. Do you still want to make a back-up before appending our modifications? [y(es)/n(o)]: \n")
        if mod.lower() == "y" or mod.lower() == "yes":
            backup()
            print "[+] Back-up was made, it's available at: %s\n" % str(bak)
            logdata.write("[+] Back-up was made, it's available at: %s\n" % str(bak))
        elif mod.lower() == "n" or mod.lower() == "no":
            print "[*] No back-up will be made.\n"
            logdata.write("[*] No back-up will be made.\n")
        else:
            print "[-] Input couldn't be understood. Making back-up for safety reasons.\n"
            logdata.write("\n[-] Input couldn't be understood. Making back-up for safety reasons.\n")
            backup()

def execute():
    global fstab
    print "[+] Starting engines.\n"
    logdata.write("\n[+] Starting engines.\n")
    if argv[1] == cmn:
        if len(argv) < 5 or len(argv) >= 6:
            print "[-] Invalid arguments specified. You must specify (in order): <mounting device> <mounting point> <filesystem>\n"
            logdata.write("\n[-] Invalid arguments specified. You must specify (in order): <mounting device> <mounting point> <filesystem>\n")
            logdata.close()
            exit(0)
        common = {'mountdev': argv[2], 'mountpoint': argv[3], 'filesystem': argv[4], 'mntops': "defaults", 'freq': "1", 'passno': "2"}
        print "[i] Common switch detected. Using the common template (<options> + mtops: defaults; fs_freq: 1; fs_passno: 2)\n"
        logdata.write("[i] Common switch detected. Using the common template (<options> + mtops: defaults; fs_freq: 1; fs_passno: 2)\n")
        cmnfg = common['mountdev']+" "+common['mountpoint']+"\t"+common['filesystem']+" "+common['mntops']+"\t"+common['freq']+" "+common['passno']
        execcmdc = "echo \""+cmnfg+"\" >> "+fstab
        try:
            cmd(execcmdc)
            print "[i] Executed: echo \""+cmnfg+"\" >> "+fstab+"\n"
            logdata.write("[i] Executed: echo \""+cmnfg+"\" >> "+fstab+"\n")
        except Exception as e:
            print "[-] Something went wrong. I hope that the back-up comes in handy if you chose to make one. Sorry :-(\n[*] Debugging info:\n"
            logdata.write("\n[-] Something went wrong. I hope that the back-up comes in handy if you chose to make one. Sorry :-(\n[*] Debugging info:\n")
            logdata.close()
            raise e
        print "[+] Fstab file [%s] successfully updated.\n" % str(fstab)
        logdata.write("\n[+] Fstab file [%s] successfully updated.\n" % str(fstab))
    else:
        pass
    if len(argv) == 7:
        if len(argv) < 7 or len(argv) >= 8:
            print "[-] Invalid arguments specified. You must specify (in order): <mounting device> <mounting point> <filesystem> <mount ops> <fs_freq> <fs_passno>\n"
            logdata.write("\n[-] Invalid arguments specified. You must specify (in order): <mounting device> <mounting point> <filesystem> <mount ops> <fs_freq> <fs_passno>\n")
            exit(0)
        allfields = {'mountdev': argv[1], 'mountpoint': argv[2], 'filesystem': argv[3], 'mntops': argv[4], 'freq': argv[5], 'passno': argv[6]}
        print "[+] Adding your options to the fstab file located at [%s]\n" % str(fstab)
        logdata.write("[+] Adding your options to the fstab file located at [%s]\n" % str(fstab))
        allfdscfg = allfields['mountdev']+" "+allfields['mountpoint']+"\t"+allfields['filesystem']+" "+allfields['mntops']+"\t"+allfields['freq']+" "+allfields['passno']
        execcmda = "echo \""+allfdscfg+"\" >> "+fstab
        try:
            cmd(execcmda)
            print "[i] Executed: echo \""+allfdscfg+"\" >> "+fstab+"\n"
            logdata.write("[i] Executed: echo \""+allfdscfg+"\" >> "+fstab+"\n")
        except Exception as e:
            print "[-] Something went wrong. I hope that the back-up comes in handy if you chose to make one. Sorry :-(\n[*] Debugging info:\n"
            logdata.write("\n[-] Something went wrong. I hope that the back-up comes in handy if you chose to make one. Sorry :-(\n[*] Debugging info:\n")
            logdata.close()
            raise e
        print "[+] Fstab file [%s] successfully updated.\n" % str(fstab)
        logdata.write("\n[+] Fstab file [%s] successfully updated.\n" % str(fstab))

def main():
    global fstab
    print "[i] Please wait while processing the config.\n"
    logdata.write("[i] Please wait while processing the config.\n")
    readconf(config)
    print "[i] Checking the fstab file located at [%s]" % str(fstab)
    logdata.write("\n[i] Checking the fstab file located at [%s]\n" % str(fstab))
    checkfstab()
    execute()
    logdata.write("="*75+"\n == END OF LOG AT "+strftime("%a, %d %b %Y %H:%M:%S")+" OF PROCESS ==\n")
    logdata.close()


if __name__ == "__main__":
    main()
