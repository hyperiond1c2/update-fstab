#!/usr/bin/python
# Version [0.1]
# ---------------
# Starts up by checking on your fstab file
#
# Updating your conf with the checksum by using default 0xffffffff /
# or by using the one you've specified in arguments applied on fstab
#
# Updates your python script by writing the checksum for your config /
# with default 0xffffffff or by using the one you've specified in args
# ============================================================================================================
# If you find any issues send them to me at roeglobal@insicuri.net and use my public PGP key (else no reply):
#     http://sprunge.us/UNOC
# ============================================================================================================

try:
    from optparse import OptionParser
    from optparse import OptionGroup
    from binascii import crc32
    from time import strftime
    from os import system as cmd
except (ImportError, Exception) as IEE:
    print "[-] You're missing a module or something went wrong.\n[*] Because I am not *that* bad, here is some debugging info:\n"
    raise IEE

# setting the parsers
parser = OptionParser("\n\nDescription:\n[1] Starts up by checking on your fstab file and establishes checksum value (defaults if not specified);\n[2] Creates back-up after your files into local directory as an .tar archive;\n[3] Updates your config with the checksum of fstab file you've specified (defaults if not specified);\n[4] Updates your python script with the checksum of the config (defaults if not specified).")
parser.add_option("-c", "--checksum", help="checksum [default: 0xffffffff]", dest="checksum", type="string")
parser.add_option("-f", "--fstab", help="fstab file [default: /etc/fstab]", dest="fstab", type="string")
parser.add_option("-o", "--config", help="config file [default: update-fstab.conf]", dest="config", type="string")
parser.add_option("-s", "--script", help="script file [default: update-fstab.py]", dest="script", type="string")

(opts, args) = parser.parse_args()
# -- - - - - - - - - - - - - - - --

# -- the vars --
crcnod = opts.checksum
config = opts.config
script = opts.script
fstab = opts.fstab
# -- -- -- -- -- -- -- --

if opts.checksum is None:
    print "[*] Checksum was not specified. Using default: 0xffffffff"
    crcnod = "0xffffffff"

if opts.config is None:
    print "[*] Config file was not specified. Using default: update-fstab.conf"
    config = "update-fstab.conf"

if opts.script is None:
    print "[*] Script file was not specified. Using default: update-fstab.py"
    script = "update-fstab.py"

if opts.fstab is None:
    print "[*] The fstab file was not specified. Using default with path: /etc/fstab\n"
    fstab = "/etc/fstab"
    
def checksum(obj):
    try:
        fobj = open(obj, "r").read()
    except Exception as e:
        print "[-] Something went wrong.\n[*] Debugging info:\n"
        raise e
    return str(float(crc32(fobj) & int(crcnod, 16)))[:-2]

def up2date(fobj, obj, csum):
    data = open(fobj, "rb").readlines()
    writeto = open(obj, "w")
    for line in data:
        if "confcache =" in line:
            writeto.write("confcache = %s # config cache - automated at: %s\n" % (csum, strftime("%a, %d %b %Y %H:%M:%S")))
        elif "cache:" in line:
            writeto.write("cache:%s\n" % csum)
        else:
            writeto.write(line)
    writeto.close()


def main():
    print "[+] Creating back-up with your files."
    try:
        cmd("tar -cf fstab_config_script-"+strftime("%d_%b_%Y-%H_%M_%S")+".tar "+fstab+" "+config+" "+script)
        print "[i] Executed with success: tar -cf fstab_config_script-"+strftime("%d_%b_%Y-%H_%M_%S")+".tar "+fstab+" "+config+" "+script
    except Exception as e:
        print "[-] Something went wrong.\n[*] Debugging info:\n"
        raise e
    
    print "\n[+] Updating the config file with fstab checksum."
    try:
        up2date(config, config, checksum(fstab))
    except Exception as e:
        print "[-] Something went wrong.\n[*] Debugging info:\n"
        raise e
    
    print "[+] Updating the script file with the config checksum."
    try:
        up2date(script, script, checksum(config))
    except Exception as e:
        print "[-] Something went wrong.\n[*] Debugging info:\n"
        raise e
    
    print "\n[+] Done.\n"


if __name__ == "__main__":
    print "[i] Engines started [%s]\n" % strftime("%a, %d %b %Y %H:%M:%S")
    main()
